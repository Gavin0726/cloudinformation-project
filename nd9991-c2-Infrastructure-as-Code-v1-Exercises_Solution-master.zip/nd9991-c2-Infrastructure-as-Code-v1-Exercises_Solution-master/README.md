## ND9991 - C2 - Infrastructure as Code - Solution to Exercises
This repo contains the solution to the exercises of **ND9991 - C2 - Infrastructure as Code** course.

In the classroom, there is an exercise in the last concept of each lesson. There are the following 5 lessons:
1. lesson-1-Getting Started with CloudFormation
2. lesson-2-Infrastructure as Code
3. lesson-3-Networking Infrastructure
4. lesson-4-Servers and Security Groups
5. lesson-5-Storage and Databases

The solution to each exercise is present in the corresponding lesson folder in this repository 
